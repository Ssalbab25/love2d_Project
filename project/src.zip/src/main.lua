--[[
1. 0, 0 위치에 x축 y축을 그리자.
2. 각 축 색은 빨간색, 녹색으로 하자.
3. 카메라를 사용하여 줌(orthoSize), 이동(move)을 테스트할 수 있도록 하자.


local Camera = require("camera")

-- 전역 변수 오염을 피하기 위해 로컬 변수로 선언
local cam

function love.load()
    -- 카메라 객체를 생성 (초기 월드 좌표: 0, 0 / orthoSize: 5)
    cam = Camera:new(0, 0, 5)
end

function love.update(dt)
    -- 1. 카메라 이동 제어 (WASD 또는 방향키)
    local moveSpeed = 8 * dt -- 기본 이동 속도 (초당 8 월드 유닛)
    -- 카메라의 시야 크기(orthoSize)에 비례해서 이동 속도를 스케일링하여,
    -- 줌아웃 상태에서는 빠르게, 줌인 상태에서는 정밀하게 이동할 수 있게 함
    moveSpeed = moveSpeed * (cam:getOrthoSize() / 5)

    local dx = 0
    local dy = 0

    if love.keyboard.isDown("a") or love.keyboard.isDown("left") then
        dx = -moveSpeed
    end
    if love.keyboard.isDown("d") or love.keyboard.isDown("right") then
        dx = moveSpeed
    end
    -- 유니티 카메라는 Y축이 위로 갈수록 양수이므로:
    -- W 키나 Up 키를 누르면 카메라가 위(+Y)로 이동
    -- S 키나 Down 키를 누르면 카메라가 아래(-Y)로 이동
    if love.keyboard.isDown("w") or love.keyboard.isDown("up") then
        dy = moveSpeed
    end
    if love.keyboard.isDown("s") or love.keyboard.isDown("down") then
        dy = -moveSpeed
    end

    cam:move(dx, dy)

    -- 2. 카메라 줌 제어 (Q / E 또는 PageUp / PageDown)
    local zoomSpeed = 6 * dt
    local currentOrtho = cam:getOrthoSize()
    if love.keyboard.isDown("q") or love.keyboard.isDown("pageup") then
        cam:setOrthoSize(currentOrtho - zoomSpeed) -- Zoom In (시야 좁아짐 -> 크게 보임)
    end
    if love.keyboard.isDown("e") or love.keyboard.isDown("pagedown") then
        cam:setOrthoSize(currentOrtho + zoomSpeed) -- Zoom Out (시야 넓어짐 -> 작게 보임)
    end
end

function love.keypressed(key)
    if key == "escape" then
        love.event.quit()
    end

    -- R 키를 눌러 카메라 위치와 줌 초기화
    if key == "r" then
        cam:setPosition(0, 0)
        cam:setOrthoSize(5)
    end
end

-- 월드 그리드 그리기 (회색 선)
local function drawWorldGrid()
    love.graphics.setColor(0.5, 0.5, 0.5, 0.25)
    love.graphics.setLineWidth(0.02)

    -- -20부터 20까지 월드 단위 그리드 라인 렌더링
    for i = -20, 20 do
        if i ~= 0 then
            -- 세로선 (x = i)
            love.graphics.line(i, -20, i, 20)
            -- 가로선 (y = i)
            love.graphics.line(-20, i, 20, i)
        end
    end
end

-- 월드 축 그리기
local function drawWorldAxes()
    -- X축 (빨간색, 가로축)
    love.graphics.setColor(1, 0.2, 0.2, 0.9)
    love.graphics.setLineWidth(0.08)
    love.graphics.line(-25, 0, 25, 0)

    -- Y축 (초록색, 세로축)
    love.graphics.setColor(0.2, 1, 0.2, 0.9)
    love.graphics.line(0, -25, 0, 25)
end

-- 월드 오브젝트 렌더링
local function drawWorldObjects()
    -- 1. 월드 원점 (0,0)에 흰색 원형 그리기
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.circle("fill", 0, 0, 0.4)

    -- 2. 우상단 (3, 3) 위치에 파란색 사각형 그리기
    love.graphics.setColor(0.2, 0.6, 1, 1)
    -- 월드 기준 좌상단 좌표(2.5, 3.5), 가로세로 1 유닛
    love.graphics.rectangle("fill", 2.5, 2.5, 1, 1)

    -- 3. 좌하단 (-3, -3) 위치에 노란색 다각형(삼각형) 그리기
    love.graphics.setColor(1, 0.8, 0.2, 1)
    love.graphics.polygon("fill", -3, -2.5, -3.5, -3.5, -2.5, -3.5)
end

function love.draw()
    -- 배경색 설정 (고급스러운 다크 테마)
    love.graphics.clear(0.08, 0.08, 0.1)

    -- =========================================================================
    -- [1] 월드 스페이스 렌더링 (카메라 변환 적용)
    -- =========================================================================
    cam:attach()

    drawWorldGrid()
    drawWorldAxes()
    drawWorldObjects()

    -- 마우스 포인터의 월드 위치 계산 및 월드 좌표계에 인디케이터 그리기
    local mx, my = love.mouse.getPosition()
    local wx, wy = cam:screenToWorld(mx, my)

    -- 마우스 지점에 마젠타색 포인터와 점선 원형 그리기
    love.graphics.setColor(1, 0.2, 0.8, 0.8)
    love.graphics.setLineWidth(0.03)
    love.graphics.circle("line", wx, wy, 0.2)
    love.graphics.circle("fill", wx, wy, 0.05)

    cam:detach()
    -- =========================================================================
    -- [2] 스크린 스페이스 렌더링 (HUD 및 사용자 가이드)
    -- =========================================================================

    -- 1. HUD 패널 그리기
    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 15, 15, 370, 190, 10, 10)

    love.graphics.setColor(0.1, 0.8, 1, 1)
    love.graphics.print("=== Unity-like Orthographic Camera ===", 30, 25)

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print(string.format("Camera World Pos : (%.2f, %.2f)", cam.x, cam.y), 30, 55)
    love.graphics.print(string.format("Camera orthoSize : %.2f (Half Height)", cam:getOrthoSize()), 30, 80)
    love.graphics.print(string.format("Pixel Ratio Scale: %.2f px/unit", cam:getScale()), 30, 105)

    love.graphics.setColor(0.9, 0.9, 0.9, 1)
    love.graphics.print(string.format("Mouse Screen Pos : (%d, %d)", mx, my), 30, 135)
    love.graphics.print(string.format("Mouse World Pos  : (%.2f, %.2f)", wx, wy), 30, 160)

    -- 2. 조작 가이드 패널 그리기
    local screenWidth, screenHeight = love.graphics.getDimensions()
    love.graphics.setColor(0, 0, 0, 0.6)
    love.graphics.rectangle("fill", 15, screenHeight - 125, 410, 110, 10, 10)

    love.graphics.setColor(1, 0.9, 0.2, 1)
    love.graphics.print("Controls Keyboard:", 30, screenHeight - 115)

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("- Move Camera: WASD or Arrow Keys", 30, screenHeight - 95)
    love.graphics.print("- Zoom In/Out: Q / E (or PageUp/PageDown)", 30, screenHeight - 75)
    love.graphics.print("- Reset View : R  /  Exit Game : ESC", 30, screenHeight - 55)
end ]]



-- ============================================================================
-- 아래는 주석을 해제하지 않고 새로 추가한 활성 실행 코드 영역입니다.
-- ============================================================================

local WorldAxis = require("worldAxis")
local Player = require("player")
local Box = require("box")
local Enemy = require("enemy")

-- 다른 파일의 주석을 풀지 않기 위해, 자체적으로 간이 카메라 객체를 로컬에 정의합니다.
local cam = {
    x = 0,
    y = 0,
    orthoSize = 5
}

-- 플레이어 객체 생성 (적과 겹치지 않도록 위치 변경)
local player = Player:new(0, 5)

-- 박스 객체 생성 (월드 좌표 0, 0, 크기 20, 2배)
local box = Box:new(0, 0, 20, 0)

-- 적 객체 생성 (월드 좌표 0, 0)
local enemy = Enemy:new(0, 0, 1.2)

-- 총탄 리스트
local bullets = {}

function cam:getScale()
    local _, screenHeight = love.graphics.getDimensions()
    return screenHeight / (2 * self.orthoSize)
end

function cam:worldToScreen(wx, wy)
    local screenWidth, screenHeight = love.graphics.getDimensions()
    local scale = self:getScale()
    local sx = screenWidth / 2 + (wx - self.x) * scale
    local sy = screenHeight / 2 - (wy - self.y) * scale
    return sx, sy
end

function cam:attach()
    local screenWidth, screenHeight = love.graphics.getDimensions()
    local scale = self:getScale()
    love.graphics.push()
    love.graphics.translate(screenWidth / 2, screenHeight / 2) -- 카메라의 위치 변환을 구현하기 위해 사용
    love.graphics.scale(scale, -scale)
    love.graphics.translate(-self.x, -self.y)
end

function cam:detach()
    love.graphics.pop()
end

function cam:screenToWorld(sx, sy)
    local screenWidth, screenHeight = love.graphics.getDimensions()
    local scale = self:getScale()
    local wx = self.x + (sx - screenWidth / 2) / scale
    local wy = self.y + (screenHeight / 2 - sy) / scale
    return wx, wy
end

function love.load()
    -- 초기화가 필요하면 이곳에 작성합니다.
end

function love.update(dt)
    -- 1. 카메라 이동 (WASD만 사용)
    local moveSpeed = 8 * dt * (cam.orthoSize / 5)
    if love.keyboard.isDown("a") then
        cam.x = cam.x - moveSpeed
    end
    if love.keyboard.isDown("d") then
        cam.x = cam.x + moveSpeed
    end
    if love.keyboard.isDown("w") then
        cam.y = cam.y + moveSpeed
    end
    if love.keyboard.isDown("s") then
        cam.y = cam.y - moveSpeed
    end

    -- 2. 카메라 줌 제어 (Q/E)
    local zoomSpeed = 6 * dt
    if love.keyboard.isDown("q") then
        cam.orthoSize = math.max(0.1, cam.orthoSize - zoomSpeed)
    end
    if love.keyboard.isDown("e") then
        cam.orthoSize = math.max(0.1, cam.orthoSize + zoomSpeed)
    end

    -- 3. 박스 회전 제어 (좌우 방향키)
    local rotationSpeed = 2 * dt
    if love.keyboard.isDown("left") then
        box:rotate(-rotationSpeed)
    end
    if love.keyboard.isDown("right") then
        box:rotate(rotationSpeed)
    end

    -- 4. 플레이어 업데이트 (체력이 0이면 업데이트하지 않음)
    if player.health > 0 then
        player:update(dt)
    end

    -- 5. 적 업데이트 (총탄 발사)
    enemy:update(dt, player.x, player.y, function(bx, by, bvx, bvy)
        table.insert(bullets, { x = bx, y = by, vx = bvx, vy = bvy, radius = 0.1 })
    end)

    -- 6. 총탄 업데이트
    for i = #bullets, 1, -1 do
        local b = bullets[i]
        b.x = b.x + b.vx * dt
        b.y = b.y + b.vy * dt

        -- 총탄과 플레이어 충돌 감지
        local dx = player.x - b.x
        local dy = player.y - b.y
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist < player.radius + b.radius then
            player.health = player.health - 1
            table.remove(bullets, i)
            if player.health <= 0 then
                player:setPosition(0, 0)
                player:stop()
                player.health = 3
            end
        end

        -- 총탄이 너무 멀리 가면 제거
        if dist > 50 then
            table.remove(bullets, i)
        end
    end

    -- 7. 플레이어와 적 충돌 감지
    local collided, isYellow, normalX, normalY = enemy:checkCollision(player.x, player.y, player.radius)
    if collided and isYellow then
        -- 노란색 면에 충돌하면 적 격파
        enemy.isDead = true
    elseif collided then
        -- 다른 면에 충돌하면 반사
        player:reflect(normalX, normalY)
        player.x = player.x + normalX * 0.1
        player.y = player.y + normalY * 0.1
    end

    -- 8. 박스 충돌 감지 및 반사
    local collided, normalX, normalY, portalX, portalY = box:checkCollision(player.x, player.y, player.radius)
    if collided then
        if portalX ~= 0 or portalY ~= 0 then
            -- 포탈 이동: 위치와 속도 방향 변경
            player.x = portalX
            player.y = portalY
            player:setVelocity(normalX * 10, normalY * 10)
        else
            -- 일반 반사
            player:reflect(normalX, normalY)
            -- 충돌 후 플레이어를 박스 밖으로 약간 이동시켜 중복 충돌 방지
            player.x = player.x + normalX * 0.1
            player.y = player.y + normalY * 0.1
        end
    end
end

function love.keypressed(key)
    if key == "escape" then
        love.event.quit()
    elseif key == "r" then
        cam.x = 0
        cam.y = 0
        cam.orthoSize = 5
        player:setPosition(0, 0)
        player:stop()     -- 플레이어 정지
        player.health = 3 -- 체력 초기화
        box:setAngle(0)
        enemy:reset()     -- 적 초기화
        bullets = {}      -- 총탄 초기화
    elseif key == "space" then
        -- 스페이스바를 누르면 플레이어가 -y축으로 이동 시작
        player:startMoving(0, -10)
    elseif key == "1" then
        -- 1번키: 다각형 갯수 증가
        box:addSide()
    elseif key == "2" then
        -- 2번키: 다각형 갯수 감소
        box:removeSide()
    elseif key == "8" then
        -- 8번키: 포탈 모드 토글
        box:togglePortal()
    end
end

function love.mousemoved(x, y, dx, dy)
    -- 마우스 왼쪽 버튼을 누르고 있을 때만 목표 좌표 업데이트
    if love.mouse.isDown(1) then
        local wx, wy = cam:screenToWorld(x, y)
        player:setTarget(wx, wy)
    end
end

function love.mousepressed(x, y, button)
    local wx, wy = cam:screenToWorld(x, y)
    if button == 1 then     -- 왼쪽 마우스 버튼
        player:setTarget(wx, wy)
    elseif button == 2 then -- 오른쪽 마우스 버튼 (대시)
        player:startDash(wx, wy)
    end
end

function love.mousereleased(x, y, button)
    if button == 1 then -- 왼쪽 마우스 버튼
        player:clearTarget()
    end
end

function love.draw()
    -- 어두운 세련된 다크 테마 배경 설정
    love.graphics.clear(0.08, 0.08, 0.1)

    -- 1. 카메라 좌표계 내에서 그리기 (격자 및 월드 축)
    cam:attach()

    -- worldAxis를 이용하여 격자선, X축(빨간색), Y축(초록색) 및 축의 두께를 카메라 줌에 맞춰 그림
    WorldAxis.draw(cam)

    -- 박스 그리기
    box:draw()

    -- 적 그리기
    enemy:draw()

    -- 총탄 그리기
    for _, b in ipairs(bullets) do
        love.graphics.setColor(1, 0.5, 0, 1)
        love.graphics.circle("fill", b.x, b.y, b.radius)
    end

    -- 플레이어 그리기
    player:draw()

    cam:detach()

    -- 2. 스크린 좌표계로 카메라 및 플레이어 위치 오버레이 출력
    WorldAxis.drawCameraCoords(cam, player, 20, 20)

    -- 체력 표시 (우측)
    local screenWidth, screenHeight = love.graphics.getDimensions()
    love.graphics.setColor(1, 0.3, 0.3, 1)
    love.graphics.print("Health: " .. player.health, screenWidth - 120, 20)

    -- 체력 0 시 리스타트 문구
    if player.health <= 0 then
        love.graphics.setColor(1, 0.5, 0.5, 1)
        love.graphics.print("Press R to Restart", screenWidth / 2 - 60, screenHeight / 2)
    end

    -- 조작 설명 패널
    local screenWidth, screenHeight = love.graphics.getDimensions()
    love.graphics.setColor(0, 0, 0, 0.5)
    love.graphics.rectangle("fill", 15, screenHeight - 110, 380, 95, 8, 8)

    love.graphics.setColor(1, 0.9, 0.2, 1)
    love.graphics.print("Controls:", 25, screenHeight - 100)

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("- Move Camera: WASD", 25, screenHeight - 80)
    love.graphics.print("- Zoom In/Out: Q / E", 25, screenHeight - 60)
    love.graphics.print("- Rotate Box: Left/Right", 25, screenHeight - 40)
    love.graphics.print("- Polygon: 1(+)/2(-)  Portal: 8", 25, screenHeight - 20)
end
